HTTP services demo using NWIS realtime water q data

October 2007
Revised Nov 2019

John Fay
